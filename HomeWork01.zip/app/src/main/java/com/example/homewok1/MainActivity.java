package com.example.homewok1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class MainActivity extends AppCompatActivity {

    static String doubleArraykey="key1";
    private ProgressBar progressBar;
    private TextView tvMin, tvMax, tvAvg, tvValue,tvSelectComplexity;
    private Button btnCalc;
    private SeekBar seekBar1;

    Handler handler;
    ExecutorService threapool;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("HomeWork1");

        progressBar = findViewById(R.id.progressBar1);
        tvMin = findViewById(R.id.tv_min);
        btnCalc = findViewById(R.id.btn1_calc);
        seekBar1 = findViewById(R.id.seekBar1);
        tvMax = findViewById(R.id.tv_max);
        tvAvg = findViewById(R.id.tv_avg);
        tvValue = findViewById(R.id.tv_value);
        tvSelectComplexity = findViewById(R.id.tv_select_complexity);

        seekBar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int i = seekBar.getProgress();
                tvValue.setText((i + " times"));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        threapool = Executors.newFixedThreadPool(2);
        btnCalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(seekBar1.getProgress() == 0)) {
                    int complexity = seekBar1.getProgress();
                    progressBar.setVisibility(progressBar.VISIBLE);
                    tvAvg.setVisibility(tvAvg.INVISIBLE);
                    tvMax.setVisibility(tvMax.INVISIBLE);
                    tvMin.setVisibility(tvMin.INVISIBLE);
                    tvValue.setVisibility(tvValue.INVISIBLE);
                    seekBar1.setVisibility(seekBar1.INVISIBLE);
                    tvSelectComplexity.setVisibility(tvSelectComplexity.INVISIBLE);
                    btnCalc.setVisibility(btnCalc.INVISIBLE);
                    threapool.execute(new GetNumber(complexity));
                } else {
                    //Log.d("demo","got in to else");
                    Toast.makeText(MainActivity.this, "Complexity should not be zero", Toast.LENGTH_SHORT).show();
                }
                tvMin.setText("Minimum: ");
                tvMax.setText("Maximum: ");
                tvAvg.setText("Average: ");
            }
        });

        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message msg) {
                Log.d("demo","message received...");
                double[] receiveddata =  msg.getData().getDoubleArray(MainActivity.doubleArraykey);
                progressBar.setVisibility(progressBar.INVISIBLE);
                tvAvg.setVisibility(tvAvg.VISIBLE);
                tvMax.setVisibility(tvMax.VISIBLE);
                tvMin.setVisibility(tvMin.VISIBLE);
                tvValue.setVisibility(tvValue.VISIBLE);
                seekBar1.setVisibility(seekBar1.VISIBLE);
                tvSelectComplexity.setVisibility(tvSelectComplexity.VISIBLE);
                btnCalc.setVisibility(btnCalc.VISIBLE);
                tvMin.setText("Minimum: " + receiveddata[0]);
                tvMax.setText("Maximum: " + receiveddata[1]);
                tvAvg.setText("Average: " + receiveddata[2]);
                return false;
            }
        });
    }

    class GetNumber implements Runnable {
        int complexity;
        ArrayList<Double> arrOfDoubles = null;
        public GetNumber(int i) {
            this.complexity = i;
        }

        @Override
        public void run() {
            arrOfDoubles = HeavyWork.getArrayNumbers(complexity);;
            Log.d("demo", "so its not good "+arrOfDoubles.toString());
            double min=Double.MAX_VALUE;
            double max=Double.MIN_VALUE;
            double avg = 0.0;
            for(double d : arrOfDoubles){
                avg += d;
                if (d > max) {
                    max = d;
                }
                if (d < min) {
                    min = d;
                }
            }
            avg = avg/complexity;
            double[] sendData = new double[3];
            sendData[0] = min;
            sendData[1] = max;
            sendData[2] = avg;
            Message msg = new Message();
            Bundle bundle = new Bundle();
            bundle.putDoubleArray(doubleArraykey,sendData);
            msg.setData(bundle);
            handler.sendMessage(msg);
        }
    }
}
