package com.example.homework3v2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class City_weather extends AppCompatActivity  implements myAdapterForCityWeather.toInteractWithActivity{

    private static final String TAG ="chupbes";
    TextView tvCityAndCountry,tvForecastText,tvForecastOn,tvTeamperatureINCityWeather;
    TextView tvDayText,tvNightText,tvClickForDetails;
    ImageView ivDayIcon,ivNightIcon;
    RecyclerView rvInCityWeather;
    RecyclerView.Adapter rvAdapterINcityWeather;
    ProgressBar pbInCityWeather;
    String globalkey,cityAndCountry,apikey,forcastText,dayURL;
    Day[] days =  new Day[5];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city_weather);

        setTitle("City Weather");
        globalkey=getIntent().getExtras().getString("City_Key");
        cityAndCountry = getIntent().getExtras().getString("CityAndCountry");
        apikey =getResources().getString(R.string.apiKey);

        rvInCityWeather = findViewById(R.id.rv_in_city_weather);
        rvInCityWeather.setHasFixedSize(true);
        LinearLayoutManager rvLayoutManager = new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        rvInCityWeather.setLayoutManager(rvLayoutManager);

        ivDayIcon = findViewById(R.id.iv_Day_icon);
        ivNightIcon = findViewById(R.id.iv_night_icon);
        pbInCityWeather = findViewById(R.id.pb_in_city_weather);
        tvCityAndCountry = findViewById(R.id.tv_city_and_countryInCityWeather);
        tvForecastText = findViewById(R.id.tv_text_InCityWeather);
        tvForecastOn= findViewById(R.id.tv_forecast_on);
        tvTeamperatureINCityWeather = findViewById(R.id.tv_temperature_inCityWeather);
        tvClickForDetails = findViewById(R.id.tv_click_for_details);
        tvDayText = findViewById(R.id.tv_day_txt);
        tvNightText = findViewById(R.id.tv_night_txt);

        tvCityAndCountry.setText(cityAndCountry);

        if(isConnected()){
            new get5daysWeather().execute(globalkey,apikey);
        }else{
            Toast.makeText(City_weather.this, "Can't connect to Internet", Toast.LENGTH_SHORT).show();
        }


        tvClickForDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Intent.ACTION_VIEW, Uri.parse(dayURL));
                //optionl if category is default in manifest
                startActivity(intent);
            }
        });

        //"isSaveCitySet"
        findViewById(R.id.btn_set_as_current).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                i.putExtra("isSaveCitySet",false);
                setResult(RESULT_OK,i);
                finish();
            }
        });

        findViewById(R.id.btn_save_city).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                i.putExtra("isSaveCitySet",true);
                setResult(RESULT_OK,i);
                finish();
            }
        });

    }

    @Override
    public void selectDay(int pos) {
        setDayInCityWeather(pos);
    }

    class get5daysWeather extends AsyncTask<String,Void ,String >{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pbInCityWeather.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... str) {
            String result=null;
            final OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url("http://dataservice.accuweather.com/forecasts/v1/daily/5day/"+str[0]+"?apikey="+str[1])
                    .build();
            try {
                Response response = client.newCall(request).execute();
                if (!response.isSuccessful()) {
                    result = String.valueOf(response.code());
                } else {
                    Headers responseHeaders = response.headers();
                    for (int i = 0; i < responseHeaders.size(); i++) {
                        System.out.println(responseHeaders.name(i) + ": " + responseHeaders.value(i));
                    }
                    result = response.body().string();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Log.d(TAG, "onPostExecute: in get5daysWeather result=" + s);
            if (s.equals("503")) {
                Toast.makeText(City_weather.this, "api limit crossed", Toast.LENGTH_SHORT).show();
            } else {
                parse5daysJson(s);
            }
            findViewById(R.id.tv_condition).setVisibility(View.VISIBLE);
            findViewById(R.id.tv_day).setVisibility(View.VISIBLE);
            findViewById(R.id.tv_night).setVisibility(View.VISIBLE);
            tvClickForDetails.setVisibility(View.VISIBLE);
            ivDayIcon.setVisibility(View.VISIBLE);
            ivNightIcon.setVisibility(View.VISIBLE);
            findViewById(R.id.btn_save_city).setVisibility(View.VISIBLE);
            findViewById(R.id.btn_set_as_current).setVisibility(View.VISIBLE);
            pbInCityWeather.setVisibility(View.INVISIBLE);
        }
    }

    private void parse5daysJson(String s) {
        try {
            JSONObject root =  new JSONObject(s);
            JSONObject headLines = root.getJSONObject("Headline");
            forcastText = headLines.getString("Text");
            tvForecastText.setText(forcastText);
            Day day;
            String iconStr;
            int icon;
            JSONArray daysInfo = root.getJSONArray("DailyForecasts");
            for (int i=0;i<daysInfo.length();i++){
                JSONObject dayInfo = daysInfo.getJSONObject(i);
                day = new Day();
                day.epochForTime = dayInfo.getLong("EpochDate");
                JSONObject temp = dayInfo.getJSONObject("Temperature");
                JSONObject min = temp.getJSONObject("Minimum");
                day.tempMin = min.getDouble("Value");
                JSONObject max = temp.getJSONObject("Maximum");
                day.tempMax = max.getDouble("Value");
                JSONObject d = dayInfo.getJSONObject("Day");
                icon = d.getInt("Icon");
                if (icon<10){
                    iconStr="0"+String.valueOf(icon);
                }else{
                    iconStr=String.valueOf(icon);
                }
                day.dayIcon=iconStr;
                day.dayIconPhrase=d.getString("IconPhrase");
                JSONObject n = dayInfo.getJSONObject("Night");
                icon = n.getInt("Icon");
                if (icon<10){
                    iconStr="0"+String.valueOf(icon);
                }else{
                    iconStr=String.valueOf(icon);
                }
                day.nightIcon=iconStr;
                day.nightIconPhrase=n.getString("IconPhrase");
                day.url=dayInfo.getString("MobileLink");
                days[i]=day;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        rvAdapterINcityWeather = new myAdapterForCityWeather(days,this);
        rvInCityWeather.setAdapter(rvAdapterINcityWeather);
        setDayInCityWeather(0);
    }

    private void setDayInCityWeather(int i) {
        Day d = days[i];
        Date date = new Date((d.epochForTime)*1000);
        SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd,yyyy");
        tvForecastOn.setText("Forecast on "+sdf.format(date));
        tvTeamperatureINCityWeather.setText("Temperature "+d.tempMax+"/"+d.tempMin+" F");
        Picasso.get().load("http://developer.accuweather.com/sites/default/files/"+d.dayIcon+"-s.png").into(ivDayIcon);
        Picasso.get().load("http://developer.accuweather.com/sites/default/files/"+d.nightIcon+"-s.png").into(ivNightIcon);
        tvDayText.setText(d.dayIconPhrase);
        tvNightText.setText(d.nightIconPhrase);
        dayURL=d.url;
    }

    class Day {
        String dayIcon,nightIcon,dayIconPhrase,nightIconPhrase;
        String url;
        double tempMin,tempMax;
        Long epochForTime;
    }

    boolean isConnected(){
        ConnectivityManager cm = (ConnectivityManager)this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        return isConnected;
    }
}
