package com.example.homework3v2;

import org.ocpsoft.prettytime.PrettyTime;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class City {
    String cityKey,cityName,country,temperature,time;
    boolean favorite=false;

    String updated() throws ParseException {
        SimpleDateFormat sdf =  new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        Date d = sdf.parse(time);
        PrettyTime pt = new PrettyTime();
        return "Updated "+pt.format(d);
    }
}
