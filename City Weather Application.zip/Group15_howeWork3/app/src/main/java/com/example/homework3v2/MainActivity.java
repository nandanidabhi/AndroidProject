package com.example.homework3v2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ocpsoft.prettytime.PrettyTime;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.BlockingDeque;

import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity implements myAdapterForMain.toInteractWithMain{

    String apikey;
    String globalCity, globalCountry, GlobalKey;
    static String TAG = "chupbes";
    SharedPreferences sp;
    static String CurrentCityKeyInSp = "CurrentCityKey";
    static String CurrentCityInSp = "CurrentCity";
    static String CurrebtCountryInSp = "CurrentCountry";
    static String CitiesInSp = "Cities";
    String[] keysOfCity;
    String[] citiesForAltd;
    SharedPreferences.Editor editor;
    TextView tvThereNoCityToDisplay,tvCityAndCountry, tvCurrentNOtSet, tvWeatherText, tvTemperatureCurrent, tvUpdatedCurrent;
    ImageView ivCurrentCityWeatherIcon;
    EditText etCityInAlert,etCountryInAlert,etCityInMain,etCountryInMain;
    ProgressBar pbInMain;
    AlertDialog.Builder altdBuilder;
    RecyclerView rvInMain;
    RecyclerView.Adapter rvAdapterInMain;
    ArrayList<City> cities =  new ArrayList<>();

    void checkThisThingsFirst(){
        Gson gson = new Gson();
        String citiesInSp= sp.getString(CitiesInSp,"Nope");
        if (citiesInSp.equals("Nope")){
            Log.d(TAG, "checkThisThingsFirst: no cities in sp");
        }else{
            String[] cityArrayfromGson = gson.fromJson(citiesInSp,String[].class);
            Log.d(TAG, "checkThisThingsFirst: cityArrayfromgson len ="+cityArrayfromGson.length);
                for (int i=0;i<cityArrayfromGson.length;i++){
                    City c = new City();
                    String[] temp=cityArrayfromGson[i].split(",");
                    //cityArrayforGson[i]=c.cityKey+","+c.cityName+","+c.country+","+c.time+","+c.temperature+","+c.favorite;
                    c.cityKey=temp[0];
                    c.cityName=temp[1];
                    c.country=temp[2];
                    c.time=temp[3];
                    c.temperature=temp[4];
                    c.favorite=Boolean.valueOf(temp[5]);
                    cities.add(c);
                }
                rvInMain.setVisibility(View.VISIBLE);
                tvThereNoCityToDisplay.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("Weather App");


        apikey=getResources().getString(R.string.apiKey);
        sp = this.getSharedPreferences(getResources().getString(R.string.sharedpreferenceFileName), MODE_PRIVATE);
        editor = sp.edit();

        ivCurrentCityWeatherIcon = findViewById(R.id.iv_weather_Icon_of_current);
        pbInMain = findViewById(R.id.pb_in_main);
        tvCityAndCountry = findViewById(R.id.tv_Current_city_and_country);
        tvCurrentNOtSet = findViewById(R.id.tv_current_not_yet_saved);
        tvTemperatureCurrent = findViewById(R.id.tv_temperature_of_current);
        tvUpdatedCurrent = findViewById(R.id.tv_updated_of_current);
        tvWeatherText = findViewById(R.id.tv_weathertText);
        etCityInMain = findViewById(R.id.et_city_inMain);
        etCountryInMain =  findViewById(R.id.et_country_inMain);
        altdBuilder = new AlertDialog.Builder(this);
        tvThereNoCityToDisplay = findViewById(R.id.tv_thereAreNOCityToDisplay);
        rvInMain = findViewById(R.id.rv_in_main);

        checkThisThingsFirst();

        rvInMain.setHasFixedSize(true);
        LinearLayoutManager rvLayoutmanager = new LinearLayoutManager(this);
        rvInMain.setLayoutManager(rvLayoutmanager);
        rvAdapterInMain= new myAdapterForMain(cities,MainActivity.this);
        rvInMain.setAdapter(rvAdapterInMain);

        LayoutInflater lid = LayoutInflater.from(this);
        View ll = lid.inflate(R.layout.alert_view_for_set_current_city,null);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(ll);
        final AlertDialog altd1 = builder.create();

        //String spSavedKey=sp.getString(CurrentCityKeyInSp,"Nope");
        GlobalKey=sp.getString(CurrentCityKeyInSp,"Nope");
        if (!GlobalKey.equals("Nope")){
            globalCity=sp.getString(CurrentCityInSp,"Nope");
            globalCountry=sp.getString(CurrebtCountryInSp,"Nope");
            Log.d(TAG, "onCreate: globalcity"+globalCity);
            Log.d(TAG, "onCreate: globalcountry"+globalCountry);
            if(isConnected()){
                new getCurrentCondtion("setCurrentcity").execute(GlobalKey, apikey);
            }else{
                Toast.makeText(this, "Connect to internet and open app again", Toast.LENGTH_LONG).show();
            }
        }


        findViewById(R.id.btn_set_current_city).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                altd1.show();
            }
        });

        etCityInAlert = ll.findViewById(R.id.et_city);
        etCountryInAlert = ll.findViewById(R.id.et_country);
        ll.findViewById(R.id.btn_ok).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                globalCity = etCityInAlert.getText().toString().trim();
                Log.d(TAG, "onClick: in set current alert global city="+globalCity);
                globalCountry = etCountryInAlert.getText().toString().trim().toUpperCase();
                Log.d(TAG, "onClick: in ser current alert global country="+globalCountry);
                if(globalCountry.equals("") || globalCity.equals("")){
                    Toast.makeText(MainActivity.this, "Input field Should not be empty", Toast.LENGTH_SHORT).show();
                }else {
                    if (isConnected()) {
                        new getCities("setCurrentcity").execute(globalCountry, apikey, globalCity);
                    } else {
                        Toast.makeText(MainActivity.this, "Can't connect to Internet", Toast.LENGTH_SHORT).show();
                    }
                }
                altd1.cancel();
            }
        });

        ll.findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                altd1.cancel();
            }
        });

        tvCityAndCountry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                altd1.show();
            }
        });

        findViewById(R.id.btn_search_city_inMain).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                globalCountry = etCountryInMain.getText().toString().trim().toUpperCase();
                globalCity = etCityInMain.getText().toString().trim();
                if(globalCountry.equals("") || globalCity.equals("")){
                    Toast.makeText(MainActivity.this, "Input field Should not be empty", Toast.LENGTH_SHORT).show();
                }else{
                    if(isConnected()){
                        new getCities("findCity").execute(globalCountry,apikey,globalCity);
                    }else{
                        Toast.makeText(MainActivity.this, "Can't connect to Internet", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK && requestCode==100){
            if(isConnected()){
                if(data.getExtras().getBoolean("isSaveCitySet")){
                    //Save City
                    Log.d(TAG, "onActivityResult: in save city");
                    new getCurrentCondtion("saveCity").execute(GlobalKey, apikey);
                }else{
                    //set as current
                    Log.d(TAG, "onActivityResult: in set current city");
                    new getCurrentCondtion("setCurrentcity").execute(GlobalKey, apikey);
                }
            }else {
                Toast.makeText(MainActivity.this, "Can't connect to Internet", Toast.LENGTH_SHORT).show();
            }

        }
    }

    @Override
    public void delete(int pos) {
        Log.d(TAG, "delete: pos"+pos);
        cities.remove(pos);
        rvAdapterInMain.notifyDataSetChanged();
        if (cities.size()==0){
            rvInMain.setVisibility(View.INVISIBLE);
            tvThereNoCityToDisplay.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void changeFavorite(int pos,boolean b) {
        cities.get(pos).favorite=b;
        rvAdapterInMain.notifyDataSetChanged();
    }

    class getCities extends AsyncTask<String, Void, String> {

        String todo;

        public getCities(String todo) {
            this.todo = todo;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pbInMain.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... str) {
            Log.d(TAG, "doInBackground: in getcities str[0]," +str[0]+
                    "str[1]," +str[1]+
                    "str[2]"+str[2]);
            String result = null;
            final OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url("http://dataservice.accuweather.com/locations/v1/cities/" + str[0] + "/search?apikey=" + str[1] + "&q=" + str[2])
                    .build();
            try {
                Response response = client.newCall(request).execute();
                if (!response.isSuccessful()) {
                    result = String.valueOf(response.code());
                } else {
                    Headers responseHeaders = response.headers();
                    for (int i = 0; i < responseHeaders.size(); i++) {
                        System.out.println(responseHeaders.name(i) + ": " + responseHeaders.value(i));
                    }
                    result = response.body().string();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Log.d(TAG, "onPostExecute: in getcities result=" + s);
            if (s.equals("[]")){
                Toast.makeText(MainActivity.this, "City Not found", Toast.LENGTH_SHORT).show();
            } else if (s.equals("503")) {
                Toast.makeText(MainActivity.this, "api limit crossed", Toast.LENGTH_SHORT).show();
            } else {
                switch (todo){
                    case "setCurrentcity":
                        ParseJsonForKey(s);
                        break;
                    case "findCity":
                        ParseJsonForCities(s);
                        break;
                    default:
                        Toast.makeText(MainActivity.this, "do proper switch case in get city", Toast.LENGTH_SHORT).show();
                }
            }
            pbInMain.setVisibility(View.INVISIBLE);
        }
    }

    private void ParseJsonForCities(String s) {
        Log.d(TAG, "ParseJsonForCities: called with s="+s);
        try {
            JSONArray root =  new JSONArray(s);
            int size=root.length();
            keysOfCity = new String[size];
            citiesForAltd = new String[size];
            JSONObject cityObj,adminArea;
            String city,state;
            cityObj = root.getJSONObject(0);
            keysOfCity[0]=cityObj.getString("Key");
            city = cityObj.getString("EnglishName");
            globalCity=city;
            JSONObject country = cityObj.getJSONObject("Country");
            globalCountry = country.getString("ID");
            adminArea = cityObj.getJSONObject("AdministrativeArea");
            state = adminArea.getString("ID");
            citiesForAltd[0]=city+","+state;
            for (int i=0;i<root.length();i++){
                cityObj = root.getJSONObject(i);
                keysOfCity[i]=cityObj.getString("Key");
                city = cityObj.getString("EnglishName");
                adminArea = cityObj.getJSONObject("AdministrativeArea");
                state = adminArea.getString("ID");
                citiesForAltd[i]=city+","+state;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        altdBuilder.setItems(citiesForAltd, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Log.d(TAG, "onClick: in dialogInterface pos="+which);
                Intent i =  new Intent(MainActivity.this,City_weather.class);
                GlobalKey=keysOfCity[which];
                i.putExtra("City_Key",GlobalKey);
                i.putExtra("CityAndCountry",globalCity+","+globalCountry);
                startActivityForResult(i,100);
            }
        });
        pbInMain.setVisibility(View.INVISIBLE);
        altdBuilder.setTitle("Select City");
        AlertDialog altdforCity = altdBuilder.create();
        altdforCity.show();
    }

    private void ParseJsonForKey(String s) {
        try {
            JSONArray root = new JSONArray(s);
            JSONObject city = root.getJSONObject(0);
            globalCity = city.getString("EnglishName");
            GlobalKey = city.getString("Key");
            JSONObject country = city.getJSONObject("Country");
            globalCountry = country.getString("ID");
            //globalCity = city.getString("EnglishName");
            //globalCountry =  city.getString("")
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if(isConnected()){
            new getCurrentCondtion("setCurrentcity").execute(GlobalKey, apikey);
        }else{
            Toast.makeText(MainActivity.this, "Can't connect to Internet", Toast.LENGTH_SHORT).show();
        }
    }

    class getCurrentCondtion extends AsyncTask<String, Void, String> {

        String todo;

        public getCurrentCondtion(String todo) {
            this.todo = todo;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pbInMain.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... str) {
            String result = null;
            Log.d(TAG, "doInBackground: in get current str[0]," +str[0]+
                    "str[1]"+str[1]);
            final OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url("http://dataservice.accuweather.com/currentconditions/v1/" + str[0] + "?apikey=" + str[1])
                    .build();
            try {
                Response response = client.newCall(request).execute();
                if (!response.isSuccessful()) {
                    result = String.valueOf(response.code());
                } else {
                    Headers responseHeaders = response.headers();
                    for (int i = 0; i < responseHeaders.size(); i++) {
                        System.out.println(responseHeaders.name(i) + ": " + responseHeaders.value(i));
                    }
                    result = response.body().string();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Log.d(TAG, "onPostExecute: in get current condition result=" + s);
            if (s.equals("[]")){
                Toast.makeText(MainActivity.this, "City Not found", Toast.LENGTH_SHORT).show();
            } else if (s.equals("503")) {
                Toast.makeText(MainActivity.this, "api limit crossed", Toast.LENGTH_SHORT).show();
            } else {
                switch (todo){
                    case "setCurrentcity":
                        ParseJsonForCurrentCityAndSetIt(s);
                        break;
                    case "saveCity":
                        ParseJsonForSaveCity(s);
                        break;
                    default:
                        Toast.makeText(MainActivity.this, "do proper switch case in get current condition", Toast.LENGTH_SHORT).show();
                }
            }
            pbInMain.setVisibility(View.INVISIBLE);
        }
    }

    private void ParseJsonForSaveCity(String s) {
        Log.d(TAG, "ParseJsonForSaveCity: called");
        String Temperature;
        City c = new City();
        try {
            JSONArray root = new JSONArray(s);
            JSONObject cityInfo = root.getJSONObject(0);
            c.time = cityInfo.getString("LocalObservationDateTime");
            JSONObject temperature =  cityInfo.getJSONObject("Temperature");
            JSONObject imperial = temperature.getJSONObject("Imperial");
            Temperature = "Temperature "+String.valueOf(imperial.getInt("Value"))+" F";
            c.cityName=globalCity;
            c.country=globalCountry;
            c.temperature=Temperature;
            c.cityKey=GlobalKey;
            String[] toCheckWhere = toCheckWhere(c);
            if(toCheckWhere[0].equals("1")){
                //city is there
                City toReplace = cities.get(Integer.valueOf(toCheckWhere[1]));
                toReplace.time=c.time;
                Toast.makeText(this, "City Updated", Toast.LENGTH_SHORT).show();
            }else{
                //add city in cities
                cities.add(c);
                Toast.makeText(this, "City Saved", Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        tvThereNoCityToDisplay.setVisibility(View.INVISIBLE);
        rvInMain.setVisibility(View.VISIBLE);
        rvAdapterInMain.notifyDataSetChanged();
        pbInMain.setVisibility(View.INVISIBLE);
        Log.d(TAG, "ParseJsonForSaveCity: completed");
    }

    private String[] toCheckWhere(City c) {
        String[] result = new String[2];
        result[0]="0";
        for(int i=0;i<cities.size();i++){
            if (cities.get(i).cityKey.equals(c.cityKey)){
                result[0]="1";
                result[1]=String.valueOf(i);
                break;
            }
        }
        return result;
    }

    private void ParseJsonForCurrentCityAndSetIt(String s) {
        String time,weatherText,Temperature,imageIconStr;
        String spSavedKey=sp.getString(CurrentCityKeyInSp,"Nope");
        Log.d(TAG, "ParseJsonForCurrentCityAndSetIt: getting key from sp="+spSavedKey);
        int imageIcon;
        try {
            JSONArray root = new JSONArray(s);
            JSONObject cityInfo = root.getJSONObject(0);
            time = cityInfo.getString("LocalObservationDateTime");
            weatherText = cityInfo.getString("WeatherText");
            imageIcon = cityInfo.getInt("WeatherIcon");
            if (imageIcon<10){
                imageIconStr="0"+String.valueOf(imageIcon);
            }else{
                imageIconStr=String.valueOf(imageIcon);
            }
            JSONObject temperature =  cityInfo.getJSONObject("Temperature");
            JSONObject imperial = temperature.getJSONObject("Imperial");
            Temperature = "Temperature "+String.valueOf(imperial.getInt("Value"))+" F";
            tvCityAndCountry.setText(globalCity+", "+globalCountry);
            tvWeatherText.setText(weatherText);
            //time=time.substring(0,time.lastIndexOf("-"));
            SimpleDateFormat sdf =  new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            Date d = sdf.parse(time);

            Log.d(TAG, "ParseJsonForCurrentCityAndSetIt: time after parsing"+d.toString());
            PrettyTime pt = new PrettyTime();
            tvUpdatedCurrent.setText("Updated "+pt.format(d));
            tvTemperatureCurrent.setText(Temperature);
            Picasso.get().load("http://developer.accuweather.com/sites/default/files/"+imageIconStr+"-s.png").into(ivCurrentCityWeatherIcon);
//            , new Callback() {
//                @Override
//                public void onSuccess() {
//                    Toast.makeText(MainActivity.this, "Image found", Toast.LENGTH_SHORT).show();
//                }
//
//                @Override
//                public void onError(Exception e) {
//                    Toast.makeText(MainActivity.this, "Image not found", Toast.LENGTH_SHORT).show();
//                }
//            });
            //Toast.makeText(this, "Current City details saved", Toast.LENGTH_SHORT).show();
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if(spSavedKey.equals(GlobalKey)){
            Toast.makeText(this, "Current City Updated", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Current City Saved", Toast.LENGTH_SHORT).show();
            editor.putString(CurrentCityInSp,globalCity);
            editor.putString(CurrebtCountryInSp,globalCountry);
            editor.putString(CurrentCityKeyInSp, GlobalKey);
            editor.commit();
        }
        tvCurrentNOtSet.setVisibility(View.INVISIBLE);
        tvCityAndCountry.setVisibility(View.VISIBLE);
        tvTemperatureCurrent.setVisibility(View.VISIBLE);
        tvUpdatedCurrent.setVisibility(View.VISIBLE);
        tvWeatherText.setVisibility(View.VISIBLE);
        ivCurrentCityWeatherIcon.setVisibility(View.VISIBLE);
        findViewById(R.id.btn_set_current_city).setVisibility(View.INVISIBLE);
        pbInMain.setVisibility(View.INVISIBLE);
    }

    boolean isConnected(){
        ConnectivityManager cm = (ConnectivityManager)this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        return isConnected;
    }
//new getCurrentCondtion("saveCity").execute(GlobalKey, apikey);
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Gson gson = new Gson();
        if (cities.size()==0){
            Log.d(TAG, "onDestroy: size 0");
            editor.putString(CitiesInSp,"Nope");
        }else {
            String[] cityArrayforGson = new String[cities.size()];
            for (int i = 0; i < cities.size(); i++) {
                City c = cities.get(i);
                cityArrayforGson[i] = c.cityKey + "," + c.cityName + "," + c.country + "," + c.time + "," + c.temperature + "," + String.valueOf(c.favorite);
            }
            String citiesJson = gson.toJson(cityArrayforGson);
            editor.putString(CitiesInSp, citiesJson);
        }
        editor.commit();
    }
}

