package com.example.shoulddo;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    static int REQ_CODE=100;
    public ImageView avatar;
    TextView firstName,lastName;
    String  check1="";
    Button save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("My profile");

        firstName = findViewById(R.id.getFname);
        lastName = findViewById(R.id.getLname);

        avatar = findViewById(R.id.getAvatar);
        avatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent getSelectedImage = new Intent(MainActivity.this,select_gender.class);
                startActivityForResult(getSelectedImage,REQ_CODE);
            }
        });
        save = findViewById(R.id.save_button);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fn=firstName.getText().toString(),ln=lastName.getText().toString();
                if(!fn.equals("")){
                    if(!ln.equals("")){
                        if(!check1.equals("")){
                            Log.d("demo","first");
                            User us1 = new User(fn,ln,check1);
                            Intent displayProfile = new Intent(MainActivity.this,display_profile.class);
                            displayProfile.putExtra("goData",us1);
                            startActivity(displayProfile);
                        }else{
                            Toast.makeText(MainActivity.this,"Select Avatar by clicking on given image",Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        lastName.setError("Can't be empty");
                    }
                }else{
                    firstName.setError("Can't be empty");
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == REQ_CODE && resultCode == RESULT_OK && data != null){
            check1 = data.getExtras().getString(select_gender.genderKey);
            if(check1.equals("female")){
                avatar.setImageDrawable(getDrawable(R.drawable.female));
            }
            if(check1.equals("male")){
                avatar.setImageDrawable(getDrawable(R.drawable.male));
            }
        }
    }
}
