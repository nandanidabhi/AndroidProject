package com.example.shoulddo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class display_profile extends AppCompatActivity {

    TextView displayName, displayGender;
    ImageView displayAvatar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_profile);
        setTitle("Display Profile");

        User us1 = (User) getIntent().getExtras().getSerializable("goData");
        displayName = findViewById(R.id.display_name);
        displayGender = findViewById(R.id.display_gender);
        displayAvatar = findViewById(R.id.display_avatar);
        displayName.setText("Name: "+us1.firstName+" "+us1.lastname);
        if(us1.gender.equals("female")){
            displayGender.setText("female");
            displayAvatar.setImageDrawable(getDrawable(R.drawable.female));
        }else{
            displayGender.setText("male");
            displayAvatar.setImageDrawable(getDrawable(R.drawable.male));
        }
        findViewById(R.id.edit_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
