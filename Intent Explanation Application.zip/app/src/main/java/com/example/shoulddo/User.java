package com.example.shoulddo;

import java.io.Serializable;

public class User implements Serializable {
    String firstName,lastname,gender;

    public User(String firstName, String lastname, String gender) {
        this.firstName = firstName;
        this.lastname = lastname;
        this.gender = gender;
    }
}
