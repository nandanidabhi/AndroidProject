package com.example.inclass11;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapterForRV extends RecyclerView.Adapter<MyAdapterForRV.ViewHolder> {

    ToCommunicateWithMainActivity ctx;
    ArrayList<Expense> ex = new ArrayList<>();

    public MyAdapterForRV(ArrayList<Expense> list,MainActivity ac) {
        ex=list;
        ctx= (ToCommunicateWithMainActivity) ac;
    }

    @NonNull
    @Override
    public MyAdapterForRV.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout rvLayout = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_layout_for_main,parent,false);
        ViewHolder viewHolder = new ViewHolder(rvLayout);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapterForRV.ViewHolder holder, final int position) {
        holder.tvTitle.setText(ex.get(position).getTitle());
        holder.tvCost.setText("$"+ex.get(position).getCost());
        holder.cons.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                ctx.deleteExpense(position);
                return false;
            }
        });
        holder.cons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ctx.showExpense(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return ex.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle,tvCost;
        ConstraintLayout cons;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle=itemView.findViewById(R.id.tv_title_inRv_inMain);
            tvCost=itemView.findViewById(R.id.tv_cost_inRv_inMain);
            cons=itemView.findViewById(R.id.constarint_inRv_inMain);
        }
    }

    interface ToCommunicateWithMainActivity{
        void deleteExpense(int x);
        void showExpense(int x);
    }
}
