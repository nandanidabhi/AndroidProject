package com.example.inclass11;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ShowExpense extends AppCompatActivity {

    Expense ex;
    String docId;
    private static final String TAG ="chupbes" ;
    TextView tvExpName,tvExpCategory,tvExpCost,tvExpDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_expense);

        setTitle("Show Expense");
        docId=getIntent().getExtras().getString("docId");
        ex = (Expense) getIntent().getExtras().getSerializable("ex");

        tvExpCategory=findViewById(R.id.tv_Expcategory_inShowExpense);
        tvExpCost=findViewById(R.id.tv_ExpAmount_inShowExpense);
        tvExpDate=findViewById(R.id.tv_Expdate_inShowExpense);
        tvExpName=findViewById(R.id.tv_ExpName_inShowExpense);

        tvExpName.setText(ex.title);
        tvExpCategory.setText(ex.category);
        tvExpCost.setText("$"+ex.cost);
        tvExpDate.setText(ex.date);

        findViewById(R.id.btn_EditExpense_inShowExpense).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ShowExpense.this,EditExpense.class);
                i.putExtra("ex",ex);
                i.putExtra("docId",docId);
                startActivity(i);
                finish();
            }
        });

        findViewById(R.id.btn_Close_inShowExpense).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
