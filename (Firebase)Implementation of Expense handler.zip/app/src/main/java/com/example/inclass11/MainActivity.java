package com.example.inclass11;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.gson.internal.$Gson$Preconditions;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements MyAdapterForRV.ToCommunicateWithMainActivity{

    private static final String TAG ="chupbes" ;
    private FirebaseFirestore db;

    TextView tvNoExpense;
    RecyclerView recyclerView;
    RecyclerView.Adapter rv_adapter;
    RecyclerView.LayoutManager rv_layoutManager;
    ArrayList<Expense> expenses = new ArrayList<>();
    ArrayList<String> docInFireStore =  new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("Expense APP");

        db = FirebaseFirestore.getInstance();

        findViewById(R.id.iv_add_inMain).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =  new Intent(MainActivity.this,AddExpense.class);
                startActivity(i);
            }
        });
        recyclerView =findViewById(R.id.rv_for_expense_inMain);
        recyclerView.setHasFixedSize(true);
        rv_layoutManager =  new LinearLayoutManager(this);
        recyclerView.setLayoutManager(rv_layoutManager);
        rv_adapter =  new MyAdapterForRV(expenses,this);
        recyclerView.setAdapter(rv_adapter);
        tvNoExpense=findViewById(R.id.tv_noExpenseText_inMain);

//        Log.d(TAG, "onSuccess: in getting expenses");
//        for (DocumentSnapshot ds : queryDocumentSnapshots){
//            docInFireStore.add(ds.getId());
//            expenses.add(ds.toObject(Expense.class));
//            Log.d(TAG, "for in get expenses called");
//        }
//        rv_adapter.notifyDataSetChanged();
        db.collection("Expenses")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                        if(e!=null){
                            Log.d(TAG, "onEvent: error in snapshot listener");
                            return;
                        }
                        for (DocumentChange dc : queryDocumentSnapshots.getDocumentChanges()) {
                            //Expense ex = new Expense();
                            switch (dc.getType()) {
                                case ADDED:
                                    Log.d(TAG, "New expense added: " + dc.getDocument().getData());
                                    //ex.title= (String) dc.getDocument().get("title");
                                    //ex.category= (String) dc.getDocument().get("category");
                                    //ex.cost= Double.valueOf((String) dc.getDocument().get("cost"));
                                    //expenses.add(ex);
                                    expenses.add(dc.getDocument().toObject(Expense.class));
                                    docInFireStore.add(dc.getDocument().getId());
                                    break;
                                case MODIFIED:
                                    Log.d(TAG, "Modified expense: " + dc.getDocument().getData());
                                    int i = docInFireStore.indexOf(dc.getDocument().getId());
                                    expenses.remove(i);
                                    //ex.title= (String) dc.getDocument().get("title");
                                    //ex.category= (String) dc.getDocument().get("category");
                                    //ex.cost= (Double) dc.getDocument().get("cost");
                                    //expenses.add(ex);
                                    expenses.add(i,dc.getDocument().toObject(Expense.class));
                                    //expenses.add(i,ex);
                                    break;
                                case REMOVED:
                                    Log.d(TAG, "Removed expense: " + dc.getDocument().getData());
                                    int j = docInFireStore.indexOf(dc.getDocument().getId());
                                    expenses.remove(j);
                                    docInFireStore.remove(j);
                                    break;
                            }
                        }
                        rv_adapter.notifyDataSetChanged();
                        checkForExpensesLength();
                    }
                });


    }

    void checkForExpensesLength(){
        if (expenses.size()==0){
            tvNoExpense.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.INVISIBLE);
        }else{
            tvNoExpense.setVisibility(View.INVISIBLE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void deleteExpense(int x) {
        String doc=docInFireStore.get(x);
        db.collection("Expenses").document(doc)
        .delete()
        .addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.d(TAG, "onFailure: in delete");
            }
        })
        .addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Log.d(TAG, "onSuccess: in delete");
                Toast.makeText(MainActivity.this, "Expense Deleted", Toast.LENGTH_SHORT).show();
            }
        });
        checkForExpensesLength();
    }

    @Override
    public void showExpense(int x) {
        Intent i = new Intent(this,ShowExpense.class);
        i.putExtra("ex",expenses.get(x));
        i.putExtra("docId",docInFireStore.get(x));
        startActivity(i);
    }
}


//        db.collection("expense")
//                .add(toSave)
//                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
//                    @Override
//                    public void onSuccess(DocumentReference documentReference) {
//                        Log.d(TAG, "onSuccess: ");
//                    }
//                })
//                .addOnFailureListener(new OnFailureListener() {
//                    @Override
//                    public void onFailure(@NonNull Exception e) {
//                        Log.d(TAG, "onFailure: ");
//                    }
//                });

//        db.collection("expense")
//                .get()
//                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
//                    @Override
//                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
//                        for(DocumentSnapshot documentSnapshot: queryDocumentSnapshots){
//                            Log.d(TAG, "onSuccess: in getting doc:"+documentSnapshot.getId()+" title :"+documentSnapshot.get("title"));
//                        }
//                    }
//                })
//                .addOnFailureListener(new OnFailureListener() {
//                    @Override
//                    public void onFailure(@NonNull Exception e) {
//                        Log.d(TAG, "onFailure: in getting document");
//                    }
//                });


//db.collection("expense").document("zDVdZAhg7OBQdPBjVMb1")
//        .update("cost",0.0)
//        .addOnFailureListener(new OnFailureListener() {
//@Override
//public void onFailure(@NonNull Exception e) {
//        Log.d(TAG, "onFailure: in delete");
//        }
//        })
//        .addOnSuccessListener(new OnSuccessListener<Void>() {
//@Override
//public void onSuccess(Void aVoid) {
//        Log.d(TAG, "onSuccess: in delete");
//        }
//        });

//db.collection("expense").document("D8KcVxgG7mi7ryOewJJJ")
//        .delete()
//        .addOnFailureListener(new OnFailureListener() {
//@Override
//public void onFailure(@NonNull Exception e) {
//        Log.d(TAG, "onFailure: in delete");
//        }
//        })
//        .addOnSuccessListener(new OnSuccessListener<Void>() {
//@Override
//public void onSuccess(Void aVoid) {
//        Log.d(TAG, "onSuccess: in delete");
//        }
//        });