package com.example.hw2musicapp;

import java.io.Serializable;

public class Results implements Serializable{
    /*String wrapperType,kind,artistId,collectionId,trackId,artistName,collectionName,trackName,collectionCensoredName,
            trackCensoredName,artistViewUrl,collectionViewUrl,trackViewUrl,previewUrl,artworkUrl30,artworkUrl60,
            artworkUrl100,collectionPrice,trackPrice,releaseDate,collectionExplicitness,trackExplicitness,
            discCount,discNumber,trackCount,trackNumber,trackTimeMillis,country,currency,primaryGenreName,isStreamable;
*/
    String artistName,trackName,primaryGenreName,collectionName,releaseDate,artworkUrl100,date,time;
    Double trackPrice,collectionPrice;
//    public Results(String artistName, String trackName, String primaryGenreName, String collectionName, String trackPrice, String collectionPrice, String releaseDate, String artworkUrl100) {
//        this.artistName = artistName;
//        this.trackName = trackName;
//        this.primaryGenreName = primaryGenreName;
//        this.collectionName = collectionName;
//        this.trackPrice = trackPrice;
//        this.collectionPrice = collectionPrice;
//        this.releaseDate = releaseDate;
//        this.artworkUrl100 = artworkUrl100;
//        this.date = date;
//        this.time = time;
//    }

    @Override
    public String toString() {
        return "Results{" +
                "artistName='" + artistName + '\'' +
                ", trackName='" + trackName + '\'' +
                ", primaryGenreName='" + primaryGenreName + '\'' +
                ", collectionName='" + collectionName + '\'' +
                ", trackPrice='" + trackPrice + '\'' +
                ", collectionPrice='" + collectionPrice + '\'' +
                ", releaseDate='" + releaseDate + '\'' +
                ", artworkUrl100='" + artworkUrl100 + '\'' +
                '}';
    }

   /* public Results(String artistName, String trackName, String primaryGenreName, String collectionName, String trackPrice,
                   String collectionPrice, String releaseDate) {
        this.artistName = artistName;
        this.trackName = trackName;
        this.primaryGenreName = primaryGenreName;
        this.collectionName = collectionName;
        this.trackPrice = trackPrice;
        this.collectionPrice = collectionPrice;
        this.releaseDate = releaseDate;
    }*/
}
