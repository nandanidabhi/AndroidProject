package com.example.hw2musicapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.w3c.dom.Text;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ResultAdapter extends ArrayAdapter<Results> {
    String date2;
    public ResultAdapter(@NonNull Context context, int resource, ArrayList<Results> objects) {
        super(context, resource,objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Results results=getItem(position);
        ViewHolder viewHolder;
        if(convertView == null)
        {
            convertView= LayoutInflater.from(getContext()).inflate(R.layout.activity_display,parent,false);
            viewHolder=new ViewHolder();
            viewHolder.track=(TextView) convertView.findViewById(R.id.track);
            viewHolder.date=(TextView) convertView.findViewById(R.id.date);
            viewHolder.artist=(TextView) convertView.findViewById(R.id.artist);
            viewHolder.price=(TextView) convertView.findViewById(R.id.price);
            convertView.setTag(viewHolder);
        }
        else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date dt = null;
        try {
            dt = format.parse(results.date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        SimpleDateFormat your_format = new SimpleDateFormat("MM-dd-yyyy");
        date2 = your_format.format(dt);

        viewHolder.track.setText("Track : "+results.trackName);
        viewHolder.artist.setText("Artist : "+results.artistName);
        viewHolder.price.setText("Price : "+results.trackPrice+"$");
        viewHolder.date.setText("Date : "+date2);


        return convertView;
    }


    private static class ViewHolder{
        TextView track,price,date,artist;
    }
}
