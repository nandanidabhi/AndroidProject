package com.example.hw2musicapp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class DisplayActivity extends AppCompatActivity {

    ImageView imageView;
    TextView trackname,genre,album,artistname,trackprice,albumprice;
    Button btn;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.displayactivity);
        setTitle("iTunes Music Search");

        Results md = (Results) getIntent().getExtras().getSerializable("Music");
        imageView=findViewById(R.id.imageView);
        Log.d("demo",md.artistName);

      Log.d("demo",md.artworkUrl100);
        Picasso.get().load(md.artworkUrl100).into(imageView);

        artistname=findViewById(R.id.artistname);
        artistname.setText("Artist : "+md.artistName);
        trackname=findViewById(R.id.trackname);
        trackname.setText("Track : "+md.trackName);
        genre=findViewById(R.id.genre);
        genre.setText("Genre : "+md.primaryGenreName);
        album=findViewById(R.id.album);
        album.setText("Album : "+md.collectionName);
        trackprice=findViewById(R.id.trackprice);
        trackprice.setText("Track Price : "+md.trackPrice+"$");
        albumprice=findViewById(R.id.albumprice);
        albumprice.setText("Album Price : "+md.collectionPrice+"$");

        btn=findViewById(R.id.finish);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }
}
