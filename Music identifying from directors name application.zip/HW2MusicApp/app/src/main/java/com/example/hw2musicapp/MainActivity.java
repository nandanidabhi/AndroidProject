package com.example.hw2musicapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends AppCompatActivity {

    static int REQ_CODE=100;
    ProgressBar progressBar;
    EditText searchkeyword;
    Button searchbtn,reset;
    SeekBar seekBar;
    ListView listView;
    TextView limit,track,price,artist;
    Switch price_date;
    int i=0;
    String baseURL="http://itunes.apple.com",dateformat;
    ArrayList<String> arr;
    String datetime;
    Results md;
    ArrayList<Results> Resultnew=new ArrayList<>();
    ArrayList<Results> Resultnew1=new ArrayList<>();
    ProgressDialog progressDoalog;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("iTunes Music Search");

        progressBar=findViewById(R.id.progressBar2);
        seekBar=findViewById(R.id.seekBar1);
        searchbtn=findViewById(R.id.searchbtn);
        reset=findViewById(R.id.reset);
        limit=findViewById(R.id.limit);
        price_date=findViewById(R.id.price_date);
        searchkeyword=findViewById(R.id.searchkeyword);
        /*track=findViewById(R.id.track);
         artist=findViewById(R.id.artist);
         price=findViewById(R.id.price);
         date=findViewById(R.id.date);*/

        //String seekvalue=String.valueOf(seekBar.getProgress());
         Log.d("demo","in connection");


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                limit.setText("Limit : "+seekBar.getProgress());

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    if(Resultnew.size()==0 || searchkeyword.getText().equals(""))
                    {
                        Toast.makeText(MainActivity.this, "No Data to reset", Toast.LENGTH_SHORT).show();
                    }
                    else
                        {
                        searchkeyword.setText("");
                        seekBar.setProgress(10);
                        limit.setText("Limit : 10");
                        price_date.setChecked(true);
                        Resultnew.clear();
                        final ResultAdapter adapter = new ResultAdapter(MainActivity.this, R.layout.activity_display, Resultnew);
                        listView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();
                    }


            }
        });

        searchbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isConnected()) {
                    Resultnew.clear();
                    String searchkeyword1 = searchkeyword.getText().toString();
                    if (searchkeyword1.equals("")) {
                        Toast.makeText(MainActivity.this, "Enter track", Toast.LENGTH_SHORT).show();
                    } else {
                        String[] resultingTokens = searchkeyword1.split(" ");

                        // for(int i=0;i<resultingTokens.length;i++) {
                        arr = new ArrayList(Arrays.asList(resultingTokens));
//                Log.d("demo",arr.get(0)+" "+arr.get(1));
                        //System.out.println("Value : "+String.valueOf(arr));
                        new GetJSONData().execute();
                    }
                }
                else
                {
                    Toast.makeText(MainActivity.this, "No Internet", Toast.LENGTH_SHORT).show();
                }
                //System.out.println(servalue[2]);

            }
        });

        price_date.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if (isConnected()) {
                    if (price_date.isChecked()) {
                        Collections.sort(Resultnew, new Comparator<Results>() {
                            @Override
                            public int compare(Results lhs, Results rhs) {
                                return lhs.date.compareTo(rhs.date);
                            }
                        });
                        showData();
                    } else {
                        Collections.sort(Resultnew, new Comparator<Results>() {
                            @Override
                            public int compare(Results lhs, Results rhs) {
                                return lhs.trackPrice.compareTo(rhs.trackPrice);
                            }
                        });

                        showData();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "No Internet", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public void progressshow()
    {
       progressDoalog=new ProgressDialog(this);
       progressDoalog.setMessage("Loading");
       progressDoalog.setCancelable(false);
       progressDoalog.show();
    }
    public void hideProgress()
    {
        progressDoalog.dismiss();
    }
    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    class GetJSONData extends AsyncTask<String,Void, ArrayList<Results>> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressshow();

        }
        @Override
        protected ArrayList<Results> doInBackground(String... strings) {
            HttpURLConnection connection=null;
            @SuppressLint("WrongThread") String seekvalue=String.valueOf(seekBar.getProgress());
            try {
                         String url2=null;
                for(int i=0;i<arr.size();i++)
                {
                    if(url2==null)
                    {
                        url2=arr.get(i).toString();
                    }
                     else {
                        if (arr.get(i) != null) {
                            url2 = url2 + "+" + arr.get(i).trim().toString();
                            Log.d("demo", url2);
                        }
                    }
                }

                Log.d("demo","in connection");

                String url=baseURL+"/search?"
                        +"term="+url2+"&limit="+seekvalue;

                URL urlB=new URL(url);
                connection=(HttpURLConnection)urlB.openConnection();
                connection.connect();
                Log.d("demo","in connection");
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF8");

                    JSONObject root = new JSONObject(json);
                    JSONArray results1 = root.getJSONArray("results");
                    Log.d("demo", String.valueOf(results1.length()));

                    if(results1.length()==0)
                    {
                        Log.d("hello", String.valueOf(results1.length()));
                        Resultnew=null;
                    }
                    else {
                        for (int i = 0; i < results1.length(); i++) {
                            JSONObject articleJSON = results1.getJSONObject(i);
                            Log.d("demo", "results" + articleJSON.getString("collectionPrice"));
                            Results person = new Results();
                            person.artistName = articleJSON.getString("artistName");
                            person.collectionName = articleJSON.getString("collectionName");
                            person.collectionPrice = articleJSON.getDouble("collectionPrice");
                            person.primaryGenreName = articleJSON.getString("primaryGenreName");
                            person.trackName = articleJSON.getString("trackName");
                            person.trackPrice = articleJSON.getDouble("trackPrice");
                            person.releaseDate =articleJSON.getString("releaseDate") ;
                            person.artworkUrl100=articleJSON.getString("artworkUrl100");
                            datetime=articleJSON.getString("releaseDate").substring(0,10) ;
                            Log.d("demo" ,datetime);
                            person.date=datetime;
                            Resultnew.add(person);
                        }
                    }
//                    Log.d("demo","in"+Resultnew.get(0).trackPrice);
                }

            }
            catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
          return Resultnew;
        }

        @Override
        protected void onPostExecute(ArrayList<Results> arrayList) {
            super.onPostExecute(arrayList);
            hideProgress();
            if(Resultnew==null)
            {
                Toast.makeText(MainActivity.this, "No Track found", Toast.LENGTH_SHORT).show();
            }
            else
                {
                showData();
            }
           // showData();
        }
    }
    void showData(){
        listView=findViewById(R.id.listview);

        Log.d("adapter","hello");
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Intent intent=new Intent(MainActivity.this,DisplayActivity.class);
                if(price_date.isChecked()) {
                    Collections.sort(Resultnew, new Comparator<Results>() {
                        @Override
                        public int compare(Results lhs, Results rhs) {
                            return lhs.date.compareTo(rhs.date);
                        }
                    });

                }
                else
                {
                    Collections.sort(Resultnew, new Comparator<Results>() {
                        @Override
                        public int compare(Results lhs, Results rhs) {
                            return lhs.trackPrice.compareTo(rhs.trackPrice);
                        }
                    });
                }
                intent.putExtra("Music",Resultnew.get(position));
               // Log.d("adapter",md.artworkUrl100);

                startActivity(intent);

            }
        });
        if(price_date.isChecked()) {
            Collections.sort(Resultnew, new Comparator<Results>() {
                @Override
                public int compare(Results lhs, Results rhs) {
                    return lhs.date.compareTo(rhs.date);
                }
            });

        }
        else
        {
            Collections.sort(Resultnew, new Comparator<Results>() {
                @Override
                public int compare(Results lhs, Results rhs) {
                    return lhs.trackPrice.compareTo(rhs.trackPrice);
                }
            });
        }
        final ResultAdapter adapter=new ResultAdapter(this,R.layout.activity_display,Resultnew);
        listView.setAdapter(adapter);
    }
    public int compare(Results p1, Results p2) {
        if (p1.trackPrice > p2.trackPrice) {
            return -1;
        } else {
            return 0;
        }
    }
   /* void showToast()
    {
        Toast.makeText(MainActivity.this, "No such Artist found", Toast.LENGTH_SHORT).show();

    }*/
}
