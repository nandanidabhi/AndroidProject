package com.example.loginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class mail extends AppCompatActivity {

    MailClass mail;
    TextView tvSenderName,tvTime,tvSubject,tvContent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mail);

        mail = (MailClass) getIntent().getExtras().getSerializable("mail");

        tvContent=findViewById(R.id.tv_mail_contetnt_inEmail);
        tvSenderName = findViewById(R.id.tv_nameOfSender);
        tvSubject = findViewById(R.id.tv_subject_inEmailView);
        tvTime = findViewById(R.id.tv_TimeWhenMailWasSent);

        tvTime.setText(mail.CreatedAt);
        tvContent.setText(mail.Message);
        tvSenderName.setText(mail.SenderName);
        tvSubject.setText(mail.Subject);

        findViewById(R.id.btn_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
