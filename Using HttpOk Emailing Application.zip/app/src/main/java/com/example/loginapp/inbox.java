package com.example.loginapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.sql.DataTruncation;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import okhttp3.FormBody;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class inbox extends AppCompatActivity implements MyAdapter.InteractWithMainActivity {

    static final String TAG="chup1";
    SharedPreferences sp;
    TextView tvName;
    String token;
    RecyclerView rvInInbox;
    RecyclerView.Adapter rv_adapter;
    RecyclerView.LayoutManager rv_layoutManager;
    String name;
    ArrayList<MailClass> mails =  new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inbox);
        Log.d(TAG, "onCreate: called");
        
        tvName =  findViewById(R.id.tv_userName_inINbox);

        sp = this.getSharedPreferences(getResources().getString(R.string.SharedPrefrence_File),MODE_PRIVATE);
        name = sp.getString("name","something");
        token = sp.getString("token","shouldHaveToken");
        tvName.setText(name);
        new retriveMails().execute(token);

        findViewById(R.id.ivb_createmail).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(inbox.this,create_new_mail.class);
                startActivity(i);
            }
        });

        findViewById(R.id.ivb_logout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("token","");
                editor.commit();
                finish();
            }
        });

        rvInInbox = findViewById(R.id.rv_in_inbox);
        rvInInbox.setHasFixedSize(true);
        rv_layoutManager = new LinearLayoutManager(this);
        rvInInbox.setLayoutManager(rv_layoutManager);
        rv_adapter = new MyAdapter(this,mails);
//        rvInInbox.setAdapter(rv_adapter);
    }

    @Override
    public void deleteItem(int position) {
        MailClass mail = mails.get(position);
        new deleteMail(position).execute(token,mail.id);
    }

    @Override
    public void openMail(int position) {
        Intent i = new Intent(inbox.this,mail.class);
        MailClass mail = mails.get(position);
        i.putExtra("mail",mail);
        startActivity(i);
    }

    class deleteMail extends AsyncTask<String,Void,String>{

        int pos;

        public deleteMail(int pos) {
            this.pos = pos;
        }

        String result,token,id;
        @Override
        protected String doInBackground(String... str) {
            token =str[0];
            id = str[1];
            final OkHttpClient client =  new OkHttpClient();
            Request request = new Request.Builder()
                    .url("http://ec2-18-234-222-229.compute-1.amazonaws.com/api/inbox/delete/"+id)
                    .header("Authorization","BEARER "+token)
                    .build();
            try {
                Response response = client.newCall(request).execute();
                if (!response.isSuccessful()) {
                    //throw new IOException("Unexpected code " + response);
                    result=response.body().string();
                }else{
                    Headers responseHeaders = response.headers();
                    for (int i = 0; i < responseHeaders.size(); i++) {
                        System.out.println(responseHeaders.name(i) + ": " + responseHeaders.value(i));
                    }
                    result =response.body().string();
                    Log.d(TAG, "doInBackground: result from delete api :"+result);
                }

                return result;
                //System.out.println(response.body().string());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            String status = null;
            JSONObject r = null;
            try {
                r = new JSONObject(s);
                status = r.getString("status");
                switch (status){
                    case "error":
                        Toast.makeText(inbox.this, r.getString("message"), Toast.LENGTH_SHORT).show();
                        break;
                    case "ok":
                        mails.remove(pos);
                        rv_adapter.notifyDataSetChanged();
                        Toast.makeText(inbox.this, "Mail deleted", Toast.LENGTH_SHORT).show();
                        break;
                    default:
                        Toast.makeText(inbox.this, "Unable to delete", Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    class retriveMails extends AsyncTask<String ,Void,String >{

        String result;
        @Override
        protected String doInBackground(String... str) {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url("http://ec2-18-234-222-229.compute-1.amazonaws.com/api/inbox")
                    .header("Authorization", "BEARER "+str[0])
                    .build();

            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

                System.out.println("Server: " + response.header("Server"));
                System.out.println("Date: " + response.header("Date"));
                System.out.println("Vary: " + response.headers("Vary"));
                result = response.body().string();
                Log.d(TAG, "doInBackground: in get mails result "+result);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            String status = null;
            JSONObject r = null;
            try {
                r = new JSONObject(s);
                status = r.getString("status");
                switch (status){
                    case "error":
                        Toast.makeText(inbox.this, r.getString("message"), Toast.LENGTH_SHORT).show();
                        break;
                    case "ok":
                        parseJsonMails(s);
                        break;
                    default:
                        Toast.makeText(inbox.this, "Unable to retrive mails", Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    private void parseJsonMails(String s) {
        try {
            MailClass mail;
            String SnederName;
            JSONObject root = new JSONObject(s);
            JSONArray messages = root.getJSONArray("messages");
            for (int i=0;i<messages.length();i++){
                mail =  new MailClass();
                JSONObject message = messages.getJSONObject(i);
                SnederName = message.getString("sender_fname")+" "+message.getString("sender_lname");
                mail.SenderName=SnederName;
                mail.Message=message.getString("message");
                mail.Subject = message.getString("subject");
                //2020-03-13 00:47:21
                SimpleDateFormat givenFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                SimpleDateFormat outputDate = new SimpleDateFormat("MMM dd, yyyy");
                String dateAndTime=message.getString("created_at");
                Date d = givenFormat.parse(dateAndTime);
                mail.CreatedAt = outputDate.format(d);
                mail.id=message.getString("id");
                mails.add(mail);
                rvInInbox.setAdapter(rv_adapter);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }

    }
}
