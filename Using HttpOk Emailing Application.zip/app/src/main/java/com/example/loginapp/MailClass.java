package com.example.loginapp;

import java.io.Serializable;

public class MailClass implements Serializable {
    String SenderName,Subject,Message,CreatedAt,id;
}
