package com.example.loginapp;

import androidx.annotation.LongDef;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.opengl.ETC1;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class sign_up extends AppCompatActivity {

    EditText etFirstName, etLastName, etEmail, etChoosePassword, etRepeatePsseord;
    static final String TAG="chup1";
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        etFirstName = findViewById(R.id.et_first_name);
        etLastName = findViewById(R.id.et_last_name);
        etEmail = findViewById(R.id.et_email_inSignUP);
        etChoosePassword = findViewById(R.id.et_choose_password);
        etRepeatePsseord = findViewById(R.id.et_repeat_password);

        Context context = sign_up.this;
        sp = context.getSharedPreferences(getResources().getString(R.string.SharedPrefrence_File),context.MODE_PRIVATE);

        findViewById(R.id.btn_sign_up).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pass, rePass;
                pass = etChoosePassword.getText().toString();
                rePass = etRepeatePsseord.getText().toString();
                if (!pass.equals(rePass)) {
                    etRepeatePsseord.setError("it should be same as above Password");
                } else {
                    new signUp().execute(etFirstName.getText().toString(),etLastName.getText().toString(),etEmail.getText().toString(),etChoosePassword.getText().toString());
                }
            }
        });
    }

    class signUp extends AsyncTask<String, Void, String> {

        String result,email,fName,lName,pass;

        @Override
        protected String doInBackground(String... str) {
            fName = str[0];
            lName = str[1];
            email = str[2];
            pass = str[3];

            final OkHttpClient client = new OkHttpClient();
            RequestBody formBody = new FormBody.Builder()
                    .add("fname", fName)
                    .add("lname", lName)
                    .add("email", email)
                    .add("password", pass)
                    .build();
            Request request = new Request.Builder()
                    .url("http://ec2-18-234-222-229.compute-1.amazonaws.com/api/signup")
                    .post(formBody)
                    .build();
            try {
                Response response = client.newCall(request).execute();
                if (!response.isSuccessful()) {
                    //throw new IOException("Unexpected code " + response);
                    result = response.body().string();
                } else {
                    Headers responseHeaders = response.headers();
                    for (int i = 0; i < responseHeaders.size(); i++) {
                        System.out.println(responseHeaders.name(i) + ": " + responseHeaders.value(i));
                    }
                    result = response.body().string();
                    Log.d(TAG, "doInBackground: result from login api :" + result);
                }
                return result;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

            @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Log.d(TAG, "onPostExecute: in signup "+s);
                String status = null;
                JSONObject r = null;
                try {
                    r = new JSONObject(s);
                    status = r.getString("status");
                    switch (status){
                        case "error":
                            Toast.makeText(sign_up.this, r.getString("message"), Toast.LENGTH_SHORT).show();
                            break;
                        case "ok":
                            parseJsonForSignUp(s);
                            break;
                        default:
                            Toast.makeText(sign_up.this, "Unable to Login", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
        }
    }

    private void parseJsonForSignUp(String s) {
        Log.d(TAG, "parseJsonForSignUp: called with s="+s);
        JSONObject root = null;
        String token;
        String name;
        try {
            root =  new JSONObject(s);
            if (root.getString("status").equals("ok")){
                token = root.getString("token");
                name = root.getString("user_fname")+" "+root.getString("user_lname");
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("token",token);
                Log.d(TAG, "parseJsonFromLoginApi: token "+token);
                editor.putString("name",name);
                Log.d(TAG, "parseJsonFromLoginApi: name"+name);
                editor.commit();
                Toast.makeText(sign_up.this, "New user has been created", Toast.LENGTH_SHORT).show();
                Intent i =  new Intent(sign_up.this,inbox.class);
                startActivity(i);
                sign_up.this.finish();
            }else{
                Toast.makeText(sign_up.this, "Login Unsuccessful", Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
