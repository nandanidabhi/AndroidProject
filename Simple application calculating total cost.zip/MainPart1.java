/*Assignment #1
 * MainPart1.java
 *Name: Nandani Chamanlal Dabhi
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainPart1 {
	/*
	 * Question 1: - In this question you will use the Data.users array that
	 * includes a list of users. Formatted as :
	 * firstname,lastname,age,email,gender,city,state - Create a User class that
	 * should parse all the parameters for each user. - Insert each of the users in
	 * a list. - Print out the TOP 10 oldest users.
	 */

	public static void main(String[] args)
	{

		// example on how to access the Data.users array.
		int i = 0;

		String[] al = new String[7];
		ArrayList<User> user=new ArrayList<User>();
		for (String str : Data.users)
		{
			String[] x1 = str.split(",");
			// System.out.println(x1[]);
			int k;
			k = Integer.parseInt(x1[2]);
			User u1 = new User(x1[0], x1[1], k, x1[3], x1[4], x1[5], x1[6]);
			// System.out.println(u1.toString());
			user.add(u1);
		}

		class AgeComparator implements Comparator<User>
		{  
			public int compare(User s1,User s2)
			{  
			if(s1.age==s2.age)  
			return 0;  
			else if(s1.age>s2.age) 
			return -1;  
			else  
			return 1;  
			}  
		}  
		
		System.out.println("Sorting by age");  
		  
		Collections.sort(user,new AgeComparator());
		
		for(i=0;i<10;i++)
		{  
			
				System.out.println("User [firstname=" + user.get(i).firstname + ", lastname=" + user.get(i).lastname + ", age=" + user.get(i).age + ", email=" + user.get(i).email
				+ ", gender=" + user.get(i).gender + ", city=" + user.get(i).city + ", state=" + user.get(i).state + "]");  
			  
		}
		
		//System.out.println(user.get(6).state);
		
		
		
		
//      for user data in list		
//		for (i = 0; i < Data.users.length; i++) {
//
//			 al = Data.users[i].split(",");
//			 System.out.println(al[1]);
//			 
//		}
		
		
//        Collections.sort(User, new Comparator<User>() {
//
//            @Override
//            public int compare(Person t, Person t1) {
//                return t.getAge() - t1.getAge();
//            }
//        });
//        System.out.println(persons);
		
	}

}