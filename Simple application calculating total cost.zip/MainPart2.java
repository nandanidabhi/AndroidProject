/*Assignment #1
 * MainPart2.java
 *Name: Nandani Chamanlal Dabhi
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

public class MainPart2 {
  
	/*
    * Question 2:
    * - In this question you will use the Data.users array that includes
    * a list of users. Formatted as : firstname,lastname,age,email,gender,city,state
    * - Create a User class that should parse all the parameters for each user.
    * - The goal is to count the number of users living each state.
    * - Print out the list of State, Count order in ascending order by count.
    * */

    public static void main(String[] args)
    {

        //example on how to access the Data.users array.
    	
     
    		int i = 0;

    		String[] al = new String[7];
    		ArrayList<User> user=new ArrayList<User>();
    		for (String str : Data.users)
    		{
    			String[] x1 = str.split(",");
    			// System.out.println(x1[]);
    			int k;
    			k = Integer.parseInt(x1[2]);
    			User u1 = new User(x1[0], x1[1], k, x1[3], x1[4], x1[5], x1[6]);
    			// System.out.println(u1.toString());
    			user.add(u1);
    			
    		}
    		
    		Map<String, Integer> c1= new HashMap<String, Integer>();
    		
    		for(i=0;i<user.size();i++)
    		{
    			if(c1.containsKey(user.get(i).state))
    			{
    				c1.put(user.get(i).state, c1.get(user.get(i).state)	+1);
    			}
    			else
    			{
    				c1.put(user.get(i).state , 1);
    			}
    		}
			System.out.println("States with count:"+c1);
			
			Map<String, Integer> sorted = c1 .entrySet() .stream() .sorted(Map.Entry.comparingByValue()).collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2, LinkedHashMap::new)); System.out.println("After sorting by values: " + sorted);
	 

			
    }

	


}
    