/*Assignment #1
 * MainPart4.java
 *Name: Nandani Chamanlal Dabhi
 */
import java.util.ArrayList;

//import java.util.HashMap;

public class MainPart4{
    /*
      Question 4
      You are provided with the Data class that contains an items array (Data.items) which is an array of items in a store. Each element in the array represents a single item record.
      Each record in the array represents a single item record. Each record is a string formatted as : Name, ID, Price. Also, you are provided with an array called
      shoppingCart (Data.shoppingCart) which is an array of items’ quantities. Each element the array represents a single item record. Each record is a string formatted as : ID,quantity. You are asked to perform the following tasks:
     1. Your implementation for this question should be included in MainPart3.java file.
     2. Create a StoreItem class that should parse all the parameters for each item. Hint: extract each value from a item's record using Java's String.split() method and set the
        delimiter to a comma, see provided code below. Each item record should to be assigned to a StoreItem object.
     3. Create the most efficient data structure that best fit the goal. Hint: The selected data structure should facilitate the retrieval of the item details based on the ID.
     4. The goal is to print out the receipt bill in the following format:
        ID  Name    Quantity    Price * Quantity
        123 Tomatoes 10         $30
        .
        .
        Total Bill: $400
    */

    public static void main(String[] args)
    {
    	int i = 0;

		String[] al = new String[7];
		ArrayList<StoreItem> st=new ArrayList<StoreItem>();
		for (String str : Data.items)
		{
			String[] x1 = str.split(",");
			// System.out.println(x1[]);
			int k,k1;
			k = Integer.parseInt(x1[1]);
			k1 = Integer.parseInt(x1[2]);
			StoreItem u1 = new StoreItem(x1[0],k,k1);
			// System.out.println(u1.toString());
			st.add(u1);
		}
		ArrayList<Shop> st1=new ArrayList<Shop>();

		for (String str : Data.shoppingCart)
		{
			String[] x1 = str.split(",");
			// System.out.println(x1[]);
			int k,k1;
			k = Integer.parseInt(x1[0]);
			k1 = Integer.parseInt(x1[1]);
			Shop u1 = new Shop(k,k1);
			// System.out.println(u1.toString());
			st1.add(u1);
		}
		String s="ID\tName\tQuantity\tPrice*Quantity";
		System.out.println(s);
		int j=0,qty=0,price=0,p1=0;
		String name=null;
		for(i=0;i<Data.shoppingCart.length;i++)
		{
			for(int z=0;z<Data.items.length;z++)
			{
				
			j=st1.get(i).id;
				if(j==st.get(z).id)
				{
					name=st.get(i).name;
					price=st.get(i).price*st1.get(i).qty;
					p1=price+p1;
				}
			
			}
			System.out.println(""+j+"\t"+name+"\t"+st1.get(i).qty+"\t"+price+"\t");
			
		}
		System.out.println("Total Bill : "+p1);
		
    }
}