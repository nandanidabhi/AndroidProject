/*Assignment #1
 * MainPart3.java
 *Name: Nandani Chamanlal Dabhi
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;

public class MainPart3 {
    /*
    * Question 3:
    * - In this question you will use the Data.users and Data.otherUsers array that includes
    * a list of users. Formatted as : firstname,lastname,age,email,gender,city,state
    * - Create a User class that should parse all the parameters for each user.
    * - The goal is to print out the users that are exist in both the Data.users and Data.otherUsers.
    * - Two users are equal if all their attributes are equal.
    * - Print out the list of users which exist in both Data.users and Data.otherUsers.
    * */

    public static void main(String[] args)
    {

		int i = 0;

		String[] al = new String[7];
		ArrayList<User> user=new ArrayList<User>();
		for (String str : Data.users)
		{
			String[] x1 = str.split(",");
			// System.out.println(x1[]);
			int k;
			k = Integer.parseInt(x1[2]);
			User u1 = new User(x1[0], x1[1], k, x1[3], x1[4], x1[5], x1[6]);
			// System.out.println(user.size());
			user.add(u1);
			
		}
		// System.out.println(user.size());

		ArrayList<User> otheruser=new ArrayList<User>();
		for (String str : Data.otherUsers)
		{
			String[] x1 = str.split(",");
			// System.out.println(x1[]);
			int k;
			k = Integer.parseInt(x1[2]);
			User u1 = new User(x1[0], x1[1], k, x1[3], x1[4], x1[5], x1[6]);
			// System.out.println(u1.toString());
			otheruser.add(u1);		
		}
		// System.out.println(otheruser.size());

		ArrayList<User> commonuser=new ArrayList<User>();
		int count=0;
		for(i=0;i<user.size();i++)
		{
			for(int j=0;j<otheruser.size();j++)
			{
//				if(user.get(i).firstname == otheruser.get(j).firstname && user.get(i).lastname == otheruser.get(j).lastname && 
//						user.get(i).age == otheruser.get(j).age && user.get(i).email == otheruser.get(j).email && user.get(i).gender == otheruser.get(j).gender && user.get(i).city == otheruser.get(j).city && user.get(i).state==otheruser.get(j).state)
//				{
//					System.out.println("User [firstname=" + otheruser.get(i).firstname + ", lastname=" + otheruser.get(i).lastname + ", age=" + otheruser.get(i).age + ", email=" + otheruser.get(i).email
//							+ ", gender=" + otheruser.get(i).gender + ", city=" + otheruser.get(i).city + ", state=" + otheruser.get(i).state + "]");  
						
				
				if(user.get(i).equals(otheruser.get(j)))
					{
					System.out.println("User [firstname=" + user.get(i).firstname + ", lastname=" + user.get(i).lastname + ", age=" + user.get(i).age + ", email=" + user.get(i).email
							+ ", gender=" + user.get(i).gender + ", city=" + user.get(i).city + ", state=" + user.get(i).state + "]");  
						
					count=count+1; 
					commonuser.add(user.get(i));
					} 
			}
		}
		
		System.out.println("Count : "+count);
		
		class NameComparator implements Comparator<User>{  
			public int compare(User s1,User s2)
			{  
			return s1.state.compareTo(s2.state);  
			}    
			}
		
		Collections.sort(commonuser, new NameComparator());
		System.out.println("After sorting");
		for(i=0;i<10;i++)
		{  
			
				System.out.println("User [firstname=" + commonuser.get(i).firstname + ", lastname=" + commonuser.get(i).lastname + ", age=" + commonuser.get(i).age + ", email=" + commonuser.get(i).email
				+ ", gender=" + commonuser.get(i).gender + ", city=" + commonuser.get(i).city + ", state=" + commonuser.get(i).state + "]");  
			  
		}
		
 }
}