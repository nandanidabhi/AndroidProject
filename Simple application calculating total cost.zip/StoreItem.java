/*Assignment #1
 * StoreItem.java
 *Name: Nandani Chamanlal Dabhi
 */
public class StoreItem
{
	String name;
	int id,price;
	public StoreItem(String name, int id, int price) {
		super();
		this.name = name;
		this.id = id;
		this.price = price;
	} 

}
