/*Assignment #1
 * Shop.java
 *Name: Nandani Chamanlal Dabhi
 */
public class Shop
{
	int id,qty;

	public Shop(int x1, int qty) {
		super();
		this.id = x1;
		this.qty = qty;
	}
}
