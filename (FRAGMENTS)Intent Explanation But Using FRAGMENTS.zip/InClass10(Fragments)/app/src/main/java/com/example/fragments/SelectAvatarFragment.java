package com.example.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;



public class SelectAvatarFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match

    private ImageView iv_female,iv_male;
    ToEditFromSelectAvatar toEditFromSelectAvatar;

    public SelectAvatarFragment(){
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        toEditFromSelectAvatar= (ToEditFromSelectAvatar) getActivity();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Select Avatar");
        View view=inflater.inflate(R.layout.fragment_select_avatar, container, false);
        iv_female=view.findViewById(R.id.iv_female);
        iv_male=view.findViewById(R.id.iv_male);
        iv_male.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            toEditFromSelectAvatar.updateEdit(false);
            }
        });
        iv_female.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toEditFromSelectAvatar.updateEdit(true);
            }
        });
        return view;
    }

    public interface ToEditFromSelectAvatar{
        void updateEdit(boolean isFemale);
    }
}
