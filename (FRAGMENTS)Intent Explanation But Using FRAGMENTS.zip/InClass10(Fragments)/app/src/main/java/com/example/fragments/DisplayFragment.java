package com.example.fragments;

import android.os.Bundle;

import androidx.annotation.LongDef;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import static android.content.ContentValues.TAG;

public class DisplayFragment extends Fragment {

    TextView txt_fullname,iv_gender_txt;
    private static String TAG="displayProfile";
    String iv_genderimagevalue,txt_name,txt_lname;
    ImageView iv_genderdisplay;
    Button btn_disp_Edit;
    FromDisplaytoMainforedit fromDisplaytoMainforedit;

    public DisplayFragment(String et_name, String et_lname,String iv_gender) {
        // Required empty public constructor
        txt_name=et_name;
        txt_lname=et_lname;
        Log.d(TAG, "DisplayFragment: "+txt_lname+" "+txt_name);
        iv_genderimagevalue=iv_gender;
    }
    public DisplayFragment(){
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fromDisplaytoMainforedit=(FromDisplaytoMainforedit)getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Display Profile");

        View view=inflater.inflate(R.layout.fragment_display, container, false);
        txt_fullname=view.findViewById(R.id.txt_disp_fullname);
        iv_gender_txt=view.findViewById(R.id.txt_disp_gender);
        iv_genderdisplay=view.findViewById(R.id.iv_gender);
        btn_disp_Edit=view.findViewById(R.id.disp_btn_edit);
        if(this.iv_genderimagevalue.equals("male")) {
            iv_genderdisplay.setImageResource(R.drawable.male);
        }else{
            iv_genderdisplay.setImageResource(R.drawable.female);
        }
        Log.d(TAG, "onCreateView: onCreate="+txt_lname+" "+txt_name);
        txt_fullname.setText("Name: "+txt_name+" "+txt_lname);
        Log.d(TAG, "onCreateView: onCreatefullname:"+txt_fullname.toString());
        iv_gender_txt.setText(iv_genderimagevalue.toUpperCase());

        btn_disp_Edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: "+txt_name+" "+txt_lname+" "+iv_genderimagevalue);
                fromDisplaytoMainforedit.toMainfromDisplayProfiletoEdit();
            }
        });
        return view;
    }
    public interface FromDisplaytoMainforedit{
            void toMainfromDisplayProfiletoEdit();
    }
}
