package com.example.fragments;

import android.icu.text.CaseMap;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageSwitcher;
import android.widget.ImageView;

import static android.content.ContentValues.TAG;

public class EditProfile_Fragment extends Fragment {

    ToAvatarFromEdit toAvatarFromEdit;

    private EditText et_name,et_lname;
    private Button btn_save;
    private ImageView iv_avatar;
    private String gender="",name="",lname="";

    public EditProfile_Fragment(){
    }
    public void setGender(String gender){
            this.gender=gender;
    }
    public void setFromDisplay(String name,String lname,String gender){

    }

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        toAvatarFromEdit= (ToAvatarFromEdit) getActivity();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        getActivity().setTitle("My Profile");
        View view=inflater.inflate(R.layout.edit_profile__fragment, container, false);
        btn_save=view.findViewById(R.id.btn_editProfile_save);
        iv_avatar=view.findViewById(R.id.iv_edit_avatar);
        et_name=view.findViewById(R.id.txt_editProfile_name);
        et_lname=view.findViewById(R.id.txt_editProfile_lname);
        if(this.gender.equals("male")) {
            iv_avatar.setImageResource(R.drawable.male);
        }
        else if(this.gender.equals("female")){
            iv_avatar.setImageResource(R.drawable.female);
        }

        et_name.setText(name);
        et_lname.setText(lname);
        Log.d(TAG, "onCreateView: inEditProfile Name:"+et_name);
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: InEditProfile: "+et_name.getText().toString());
                toAvatarFromEdit.startDisplayProfile(et_name.getText().toString(),et_lname.getText().toString(),gender);
            }
        });
        iv_avatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toAvatarFromEdit.startSelectAvatar();
            }
        });
        return view;
    }

    public interface ToAvatarFromEdit{
        void startSelectAvatar();
        void startDisplayProfile(String et_name, String et_lname,String gender);
    }

}
