package com.example.fragments;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements EditProfile_Fragment.ToAvatarFromEdit,SelectAvatarFragment.ToEditFromSelectAvatar,DisplayFragment.FromDisplaytoMainforedit{

    private static final String TAG = "MainTag";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportFragmentManager().beginTransaction()
                .add(R.id.container,new EditProfile_Fragment(),"edit")
                .commit();
    }

    @Override
    public void startSelectAvatar() {

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container,new SelectAvatarFragment(),"selectAvatar")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void startDisplayProfile(String et_name, String et_lname,String iv_gender) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container,new DisplayFragment(et_name.toString(),et_lname.toString(),iv_gender),"displayProfile")
                .addToBackStack(null)
                .commit();
        Log.d(TAG, "startDisplayProfile: "+et_name);
    }

    @Override
    public void onBackPressed() {
            if(getSupportFragmentManager().getBackStackEntryCount()>0){
                    getSupportFragmentManager().popBackStack();}
            else{
                super.onBackPressed();
            }
    }


    @Override
    public void updateEdit(boolean isFemale) {
        getSupportFragmentManager().popBackStack();
        EditProfile_Fragment newEditFragment= (EditProfile_Fragment) getSupportFragmentManager().findFragmentByTag("edit");
        if(isFemale)newEditFragment.setGender("female");
        else newEditFragment.setGender("male");
    }

    @Override
    public void toMainfromDisplayProfiletoEdit() {
        getSupportFragmentManager().popBackStack();
    }
}
