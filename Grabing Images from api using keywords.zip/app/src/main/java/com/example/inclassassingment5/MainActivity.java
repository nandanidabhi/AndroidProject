package com.example.inclassassingment5;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button btnGo;
    ImageButton ivbPrev,ivbNext;
    ImageView ivCenter,ivNext,ivPrev;
    TextView tvKeyword;
    ProgressBar pb1;
    String[] globalurls;
    final String TAG = "domo";
    Integer imageIndex=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivbPrev = findViewById(R.id.ivb_prev);
        ivbNext = findViewById(R.id.ivb_next);
        btnGo = findViewById(R.id.btn_go);
        ivCenter = findViewById(R.id.iv_center);
        ivNext = findViewById(R.id.iv_next);
        ivPrev = findViewById(R.id.iv_prev);
        tvKeyword = findViewById(R.id.tv_keyword);
        pb1 = findViewById(R.id.pb1);

        if (isConnected()){
            new Getkeywords(Boolean.FALSE).execute();
        }else{
            Toast.makeText(this, "you are not connected to internet", Toast.LENGTH_SHORT).show();
        }

        btnGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isConnected()){
                    new Getkeywords(Boolean.TRUE).execute();
                }else{
                    Toast.makeText(MainActivity.this, "you are not connected to internet", Toast.LENGTH_SHORT).show();
                }
            }
        });

        ivbNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageIndex++;
                if (imageIndex>=globalurls.length){
                    imageIndex=0;
                }
                new GetImage().execute(globalurls[imageIndex]);
            }
        });

        ivbPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageIndex--;
                if (imageIndex<0){
                    imageIndex=globalurls.length-1;
                }
                new GetImage().execute(globalurls[imageIndex]);
            }
        });
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    class Getkeywords extends AsyncTask<Void,Void, String>{
        Boolean fromcheck=false;

        public Getkeywords(Boolean fromcheck) {
            this.fromcheck = fromcheck;
        }

        @Override
        protected String doInBackground(Void... voids) {
            StringBuilder stringBuilder = new StringBuilder();
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            String result = null;
            try {
                URL url = new URL("http://dev.theappsdr.com/apis/photos/keywords.php");
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                Log.d("demo", "doInBackground: done "+connection.getResponseCode());
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line = "";
                    while ((line = reader.readLine()) != null) {
                        stringBuilder.append(line);
                    }
                    result = stringBuilder.toString();
                    Log.d("demo","keywords:"+result);
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                //Close open connections and reader
                if (connection != null) {
                    connection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String strings) {
            Log.d("htttp","strings: "+strings);
            Log.d(TAG, "onPostExecute: "+strings);
            //Toast.makeText(getApplicationContext(), strings, Toast.LENGTH_LONG).show();
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Choose a keyword");
            final String[] temp = strings.split(";");
            builder.setItems(temp, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    tvKeyword.setText(temp[which]);
                    new GetImageUrls().execute((String) tvKeyword.getText());
                }
            });
            AlertDialog altd = builder.create();
            if (fromcheck){
                altd.show();
            }
        }
    }

    class GetImageUrls extends AsyncTask<String,Void,ArrayList<String>>{

        @Override
        protected void onPreExecute() {
            pb1.setVisibility(View.VISIBLE);
            ivCenter.setVisibility(View.INVISIBLE);
        }

        @Override
        protected ArrayList<String> doInBackground(String... str) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            ArrayList<String> urls = new ArrayList<>();
            String urlGot="http://dev.theappsdr.com/apis/photos/index.php";
            String temp=str[0];
            try {
                temp=urlGot+"?keyword="+temp;
                URL url = new URL(temp);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                Log.d("demo", "doInBackground: done "+connection.getResponseCode());
                Log.d("htttp","going in if http ok");
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    Log.d("htttp","got in if http ok");
                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line = "";
                    while ((line = reader.readLine()) != null) {
                    //line = reader.readLine();
                        Log.d("htttp","line: "+line);
                        urls.add(line.trim());
                    }
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                //Close open connections and reader
                if (connection != null) {
                    connection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return urls;
        }

        @Override
        protected void onPostExecute(ArrayList<String> urls) {

            pb1.setVisibility(View.INVISIBLE);
//            globalurls = (String[]) urls.toArray();
            globalurls = new String[urls.size()];
            for (int i=0;i<urls.size();i++){
                globalurls[i]=urls.get(i);
            }
            //Log.d("htttp","global first before calling: "+globalurls[0]);
            if (urls.isEmpty() || urls.size()==1){
                ivbNext.setVisibility(View.INVISIBLE);
                ivbPrev.setVisibility(View.INVISIBLE);
                if(urls.isEmpty()){
                    Log.d("htttp","no urls");
                    Toast.makeText(MainActivity.this, "NO image to show", Toast.LENGTH_SHORT).show();
                }else{
                    new GetImage().execute(globalurls[0]);
                }
            }else {
                new GetImage().execute(globalurls[0]);
                ivbNext.setVisibility(View.VISIBLE);
                ivbPrev.setVisibility(View.VISIBLE);
            }
        }
    }

    class GetImage extends AsyncTask<String,Void,Bitmap>{

        @Override
        protected void onPreExecute() {
            pb1.setVisibility(View.VISIBLE);
            ivCenter.setVisibility(View.INVISIBLE);
        }

        @Override
        protected Bitmap doInBackground(String... str) {
            HttpURLConnection connection = null;
            Bitmap bitmap = null;

            URL url = null;
            try{
                url = new URL(str[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                Log.d("htttp","response: "+connection.getResponseCode());
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK){
                    bitmap = BitmapFactory.decodeStream(connection.getInputStream());
                    Log.d("htttp","got Bitmap");
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            pb1.setVisibility(View.INVISIBLE);
            ivCenter.setVisibility(View.VISIBLE);
            if (bitmap!=null){
                Log.d("htttp","bitmap is not null");
                ivCenter.setImageBitmap(bitmap);
            }else{
                ivCenter.setVisibility(View.INVISIBLE);
                Toast.makeText(MainActivity.this, "No Image Found", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
