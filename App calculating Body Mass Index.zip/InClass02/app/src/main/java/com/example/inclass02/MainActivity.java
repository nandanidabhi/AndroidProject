package com.example.inclass02;
/*
a. Assignment InClass02.
b. MainActivity.java.
c. Nandani Dabhi
   Phrabhav Jani
 */
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private EditText et_weight,et_height_feet,et_height_inches;
    private TextView tv_result1,tv_result;

    private Button button_calculate;
    double weight =0.0;
    int feet=0;
    int inches=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_weight=findViewById(R.id.et_weight);
        et_height_feet=findViewById(R.id.et_height_feet);
        et_height_inches=findViewById(R.id.et_height_inches);

        tv_result1=findViewById(R.id.tv_result1);
        tv_result=findViewById(R.id.result);

        button_calculate=findViewById(R.id.button_calculate);

        button_calculate.setOnClickListener(new OnClickListener()
        {

            @Override
            public void onClick(View view) {
                String weight_text=et_weight.getText().toString();
                String feet_text=et_height_feet.getText().toString();
                String inches_text=et_height_inches.getText().toString();

                if(weight_text.equals("") || weight_text.equals(0))
                {
                    et_weight.setError("Can't be Empty!!");
                    Toast.makeText(MainActivity.this, "Can't be Empty!!", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    weight=Double.parseDouble(weight_text);
                }
                if(feet_text.equals("") || feet_text.equals(0))
                {
                    et_height_feet.setError("Can't be Empty!!");
                    Toast.makeText(MainActivity.this, "Can't be Empty!!", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    feet=Integer.parseInt(feet_text);
                }
                if(inches_text.equals(""))
                {
                    et_height_inches.setError("Can't be Empty!!");
                    Toast.makeText(MainActivity.this, "Can't be Empty!!", Toast.LENGTH_SHORT).show();

                }
                else
                {
                    inches=Integer.parseInt(inches_text);
                }

                if(feet==0 && inches==0 || weight==0)
                {
                    Toast.makeText(MainActivity.this, "Can't be Empty!!", Toast.LENGTH_SHORT).show();

                }
                //  BMI = (Weight in Pounds / (Height in inches x Height in inches)) x 703 1 foot = 12 inches
                else {

                    inches = inches + feet * 12;
                    double bmi = weight / inches / inches * 703;

                    //  Log.d("demo","weight"+weight+" feet"+feet+" ")

                    TextView tvbmi=findViewById(R.id.tv_result1);
                    tvbmi.setText("Your BMI:" +bmi);
                    TextView tvbmiresult=(TextView)findViewById(R.id.result);
                    if(bmi<=18.5)
                    {
                        tvbmiresult.setText("You are underweight");
                    }
                    else if(bmi>18.5 && bmi<=24.9)
                    {
                        tvbmiresult.setText("You are Normal weight");
                    }
                    else if(bmi>=25 && bmi<29.9)
                    {
                        tvbmiresult.setText("You are overweight");
                    }
                    else
                    {
                        tvbmiresult.setText("You are Obese");
                    }
                }
            }
        });


    }
}
